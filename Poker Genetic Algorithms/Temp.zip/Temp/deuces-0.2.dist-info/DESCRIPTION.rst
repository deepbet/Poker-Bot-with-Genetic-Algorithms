Home-page: https://github.com/worldveil/deuces
Author: Will Drevo
Author-email: UNKNOWN
License: MIT
Description: See: https://github.com/worldveil/deuces
Platform: UNKNOWN
Classifier: Development Status :: 3 - Alpha
Classifier: Intended Audience :: Developers
Classifier: Intended Audience :: Education
Classifier: Intended Audience :: Science/Research
Classifier: License :: OSI Approved :: MIT License
Classifier: Topic :: Games/Entertainment
